This module extends the functionality of stock: in a picking out or a scrap the user
can only select the lots available in the origin location.
