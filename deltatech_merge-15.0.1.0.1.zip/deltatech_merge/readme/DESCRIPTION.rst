Features:
 - Merge objects
 - System parameter deltatech_merge.merge_objects_max_number can be used to define max number of objects to merge
